package aiss.api;

import java.util.HashSet;
import java.util.Set;

import aiss.api.resources.AccuweatherForecastResource;
import aiss.api.resources.AccuweatherTextSearchResource;
import aiss.api.resources.GoogleDriveResource;
import aiss.api.resources.GoogleMapsResource;

public class VIAJAISSApplication {

	private Set<Object> items = new HashSet<Object>();
	private Set<Class<?>> classes = new HashSet<Class<?>>();
	
	public VIAJAISSApplication() {
		items.add(AccuweatherTextSearchResource.getInstance());
		items.add(AccuweatherForecastResource.getInstance());
		items.add(GoogleDriveResource.getInstance());
		items.add(GoogleMapsResource.getInstance());
	}
	public Set<Class<?>> getClasses() {
		return classes;
	}

	public Set<Object> getSingletons() {
		return items;
	}
}
