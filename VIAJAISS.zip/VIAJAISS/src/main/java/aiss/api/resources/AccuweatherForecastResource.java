package aiss.api.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.jboss.resteasy.spi.NotFoundException;

import aiss.model.accuweatherForecast.AccuweatherForecastSearch;
import aiss.model.accuweatherTextSearch.AccuweatherTextSearch;
import aiss.model.repository.VIAJAISSRepository;
import aiss.model.repository.VIAJAISSRepositoryImplement;

@Path("/prediccion")
public class AccuweatherForecastResource {

	public static AccuweatherForecastResource _instance=null;
	VIAJAISSRepository repository;
	
	private AccuweatherForecastResource(){
		repository=VIAJAISSRepositoryImplement.getInstance();
	}
	
	public static AccuweatherForecastResource getInstance()
	{
		if(_instance==null)
			_instance=new AccuweatherForecastResource();
		return _instance; 
	}
	
	@GET
	@Path("/{key}")
	@Produces("application/json")
	public AccuweatherForecastSearch get(@PathParam("key" )String nombreKey) {
		AccuweatherForecastSearch prediccion= repository.getPrediccion(nombreKey);
		if(prediccion==null) {
			throw new NotFoundException("La prediccion para la ciudad buscada no fue encontrada");
		}
		return prediccion;
	}
}
