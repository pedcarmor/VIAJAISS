package aiss.api.resources;

import javax.ws.rs.*;

import org.jboss.resteasy.spi.NotFoundException;

import aiss.model.accuweatherTextSearch.AccuweatherTextSearch;
import aiss.model.repository.VIAJAISSRepository;
import aiss.model.repository.VIAJAISSRepositoryImplement;

@Path("/textSearch")
public class AccuweatherTextSearchResource {

	public static AccuweatherTextSearchResource _instance=null;
	VIAJAISSRepository repository;
	
	private AccuweatherTextSearchResource(){
		repository=VIAJAISSRepositoryImplement.getInstance();
	}
	
	public static AccuweatherTextSearchResource getInstance()
	{
		if(_instance==null)
			_instance=new AccuweatherTextSearchResource();
		return _instance; 
	}
	
	@GET
	@Path("/{ciudad}")
	@Produces("application/json")
	public AccuweatherTextSearch get(@PathParam("ciudad" )String nombreCiudad) {
		AccuweatherTextSearch key= repository.getKey(nombreCiudad);
		if(key==null) {
			throw new NotFoundException("La key " + key + " no fue encontrada");
		}
		return key;
	}
}
