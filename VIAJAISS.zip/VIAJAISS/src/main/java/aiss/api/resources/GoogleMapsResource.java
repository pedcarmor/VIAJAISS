package aiss.api.resources;

import java.util.Collection;

import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.jboss.resteasy.spi.NotFoundException;
import aiss.model.googleMaps.Result;
import aiss.model.repository.VIAJAISSRepository;
import aiss.model.repository.VIAJAISSRepositoryImplement;

@Path("/alojamientos")
public class GoogleMapsResource {
	public static GoogleMapsResource _instance=null;
	VIAJAISSRepository repository;
	
	private GoogleMapsResource(){
		repository=VIAJAISSRepositoryImplement.getInstance();
	}
	
	public static GoogleMapsResource getInstance()
	{
		if(_instance==null)
			_instance=new GoogleMapsResource();
		return _instance; 
	}
	
	@GET
	@Produces("application/json")
	public Collection<Result> getAll() {
		return repository.getAlojamientosCiudad();
	}
	
	@GET
	@Path("/{nombreCiudad}")
	@Produces("application/json")
	public Result get(@PathParam("ciudad" )String nombreCiudad) {
		Result alojamiento= repository.getAlojamientoCiudad(nombreCiudad);
		if(alojamiento==null) {
			throw new NotFoundException("La ciudad " + nombreCiudad + " no fue encontrada");
		}
		return alojamiento;
	}
	
	@PUT
	@Consumes("application/json")
	public Response updateAlojamientosCiudad(Result ciudad) {
		Result oldCiudad= repository.getAlojamientoCiudad(ciudad.getName());
		if(oldCiudad==null) {
			throw new NotFoundException("La ciudad"+ ciudad.getName() +" no fue encontrada");
		}
		if(ciudad.getId()!=null) {
			oldCiudad.setId(ciudad.getId());
		}
		return Response.noContent().build();
	}
	
	@DELETE
	@Path("/{name}")
	public Response deleteAlojamientosCiudad(@PathParam("name") String nombreCiudad) {
		Result ciudadRemoved = repository.getAlojamientoCiudad(nombreCiudad);
		if (ciudadRemoved == null) {
			throw new NotFoundException("La ciudad "+ nombreCiudad +" no fue encontrada");
			}
		else {
			repository.deleteAlojamientosCiudad(nombreCiudad);
		}
		return Response.noContent().build();
		}
}
