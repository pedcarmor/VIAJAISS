package aiss.api.resources;

import java.net.URI;
import java.util.Collection;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.ResponseBuilder;
import org.jboss.resteasy.spi.BadRequestException;
import org.jboss.resteasy.spi.NotFoundException;
import aiss.model.google.drive.FileItem;
import aiss.model.repository.VIAJAISSRepository;
import aiss.model.repository.VIAJAISSRepositoryImplement;

@Path("/archivos")
public class GoogleDriveResource {

	public static GoogleDriveResource _instance=null;
	VIAJAISSRepository repository;
	
	private GoogleDriveResource(){
		repository=VIAJAISSRepositoryImplement.getInstance();
	}
	
	public static GoogleDriveResource getInstance()
	{
		if(_instance==null)
			_instance=new GoogleDriveResource();
		return _instance; 
	}
	
	@GET
	@Produces("application/json")
	public Collection<FileItem> getAll() {
		return repository.getAllFiles();
	}
	
	@GET
	@Path("/{id}")
	@Produces("application/json")
	public FileItem get(@PathParam("id" )String idArchivo) {
		FileItem archivo= repository.getFile(idArchivo);
		if(archivo==null) {
			throw new NotFoundException("El archivo " + archivo + " no fue encontrado");
		}
		return archivo;
	}
	
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	public Response addFile(@Context UriInfo uriInfo, FileItem file) {
		
		if (file.getTitle() == null || "".equals(file.getTitle())) {
			throw new BadRequestException("El título del archivo no debe ser null o vacío");
	}
		if(file.getId()==null || "".equals(file.getId())) {
			throw new BadRequestException("El id del archivo no debe ser null o vacío");
		}
	repository.addFile(file);
	UriBuilder ub = uriInfo.getAbsolutePathBuilder().path(this.getClass(), "get");
	URI uri = ub.build(file.getId());
	ResponseBuilder resp = Response.created(uri);
	resp.entity(file);
	return resp.build();
	}
	
	@PUT
	@Consumes("application/json")
	public Response updateFile(FileItem file) {
		FileItem oldFile= repository.getFile(file.getId());
		if(oldFile==null) {
			throw new NotFoundException("El archivo"+ file.getTitle() +" no fue encontrado");
		}
		if(file.getTitle()!=null) {
			oldFile.setTitle(file.getTitle());
		}
		return Response.noContent().build();
	}
	
	@DELETE
	@Path("/{id}")
	public Response deleteFile(@PathParam("id") String idArchivo) {
		FileItem fileRemoved = repository.getFile(idArchivo);
		if (fileRemoved == null) {
			throw new NotFoundException("El archivo con id= "+ idArchivo +" no fue encontrado");
			}
		else {
			repository.deleteFile(idArchivo);
		}
		return Response.noContent().build();
		}
}
