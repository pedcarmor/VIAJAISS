package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.accuweatherForecast.AccuweatherForecastSearch;
import aiss.model.resources.AccuweatherForecastResources;

public class ForecastController extends HttpServlet {
	
	private static final long serialVersionUID=1L;
	
	private static final Logger log = Logger.getLogger(ForecastController.class.getName());
	
	public ForecastController() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Sample log
		String query = request.getParameter("ciudad");
		RequestDispatcher rd= null;
		
		//Busca el tiempo en la ciudad deseada:
		log.log(Level.FINE, "Searching for temperature in "+ query);
		AccuweatherForecastResources accuweatherForecastSearch=
				new AccuweatherForecastResources();
		AccuweatherForecastSearch accuweatherForecast = accuweatherForecastSearch.getForecast(query);
		
		if( accuweatherForecast != null) {
			request.setAttribute("temperature",  accuweatherForecast.getDailyForecasts());
			rd= request.getRequestDispatcher("/successForecast.jsp");
			
		}else {
			log.log(Level.SEVERE, "Accuweather object "+accuweatherForecast);
			rd= request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
}
