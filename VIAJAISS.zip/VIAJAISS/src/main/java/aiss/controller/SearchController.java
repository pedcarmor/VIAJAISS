package aiss.controller;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.accuweatherForecast.AccuweatherForecastSearch;
import aiss.model.googleMaps.GoogleMapsSearch;
import aiss.model.resources.AccuweatherForecastResources;
import aiss.model.resources.GoogleMapsResources;

public class SearchController extends HttpServlet {
	
	private static final long serialVersionUID=1L;
	
	private static final Logger log = Logger.getLogger(SearchController.class.getName());
	
	public SearchController() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Sample log
		String query = request.getParameter("ciudad");
		RequestDispatcher rd= null;
		
		//Buscar los alojamientos de GoogleMaps
		log.log(Level.FINE, "Searching for lodging in "+query);
		GoogleMapsResources gms= new GoogleMapsResources();
		GoogleMapsSearch googleMapsResults= gms.getResults(query);
		AccuweatherForecastResources afr= new AccuweatherForecastResources();
		AccuweatherForecastSearch accuweatherResults= afr.getForecast(query);
		
		if(googleMapsResults != null && accuweatherResults != null) {
			rd= request.getRequestDispatcher("/success.jsp");
			request.setAttribute("hotels", googleMapsResults.getResults());
			request.setAttribute("temperatures", accuweatherResults.getDailyForecasts());
		}else {
			log.log(Level.SEVERE, "Google object "+googleMapsResults);
			rd= request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
}
