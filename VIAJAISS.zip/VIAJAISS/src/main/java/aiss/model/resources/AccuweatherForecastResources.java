package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;

import aiss.model.accuweatherForecast.AccuweatherForecastSearch;
import aiss.model.accuweatherTextSearch.AccuweatherTextSearch;

public class AccuweatherForecastResources {
	private static final String ACCUWEATHER_FORECAST_API= "WCInQmGIiq1jvOCUnJXW5bYQM4OADCbt";
	private static final Logger log= Logger.getLogger(AccuweatherForecastResources.class.getName());
	
	public AccuweatherForecastSearch getForecast(String query) throws UnsupportedEncodingException{
		AccuweatherTextSearch[] keys = AccuweatherTextSearchResources.getKey(query);
		String key = keys[0].getKey();
		String clave = URLEncoder.encode(key, "UTF-8");
		String url = "http://dataservice.accuweather.com/forecasts/v1/daily/5day/"
				+clave+"?apikey="+ACCUWEATHER_FORECAST_API+"&metric=true";
		log.log(Level.FINE,"Url: "+url);
		ClientResource cr= new ClientResource(url);
		AccuweatherForecastSearch afs= cr.get(AccuweatherForecastSearch.class);
		return afs;
	}

}
