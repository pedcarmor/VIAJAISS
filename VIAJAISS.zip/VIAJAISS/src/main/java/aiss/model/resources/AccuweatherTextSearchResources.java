package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;

import aiss.model.accuweatherTextSearch.AccuweatherTextSearch;

public class AccuweatherTextSearchResources {
	private static final String ACCUWEATHER_TEXT_SEARCH_API= "WCInQmGIiq1jvOCUnJXW5bYQM4OADCbt";
	private static final Logger log= Logger.getLogger(AccuweatherTextSearchResources.class.getName());
	
	public static AccuweatherTextSearch[] getKey(String query) throws UnsupportedEncodingException{
		String location = URLEncoder.encode(query, "UTF-8");
		String url = "http://dataservice.accuweather.com/locations/v1/cities/search?"
		+"apikey="+ACCUWEATHER_TEXT_SEARCH_API+"&q="+location;
		log.log(Level.FINE,"Url: "+url);
		ClientResource cr= new ClientResource(url);
		AccuweatherTextSearch[] ats= cr.get(AccuweatherTextSearch[].class);
		return ats;
	}

}
