package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;

import aiss.model.googleMaps.GoogleMapsSearch;

public class GoogleMapsResources {
		private static final String GOOGLEMAPS_API_KEY = "AIzaSyDi7OxX8iyIKgPv3t4f9oJsZeRd9S2PcUw";
		private static final Logger log= Logger.getLogger(GoogleMapsResources.class.getName());
		
		public GoogleMapsSearch  getResults(String query) throws UnsupportedEncodingException{
			
			String location = URLEncoder.encode(query, "UTF-8");
			String url = "https://maps.googleapis.com/maps/api/place/textsearch/json?query="
			+location+"&types=lodging&language=es&key="+GOOGLEMAPS_API_KEY;
			log.log(Level.FINE,"Url: "+url);
			ClientResource cr= new ClientResource(url);
			GoogleMapsSearch gms= cr.get(GoogleMapsSearch.class);
			return gms;
		}
}
