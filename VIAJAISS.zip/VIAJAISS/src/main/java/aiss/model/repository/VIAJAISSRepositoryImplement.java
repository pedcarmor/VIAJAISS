package aiss.model.repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import aiss.model.google.drive.*;
import aiss.model.googleMaps.*;
import aiss.model.accuweatherForecast.*;
import aiss.model.accuweatherTextSearch.*;

public class VIAJAISSRepositoryImplement implements VIAJAISSRepository {
	
	Map<String, FileItem> driveMap;
	Map<String,Result> placesMap;
	Map<String,AccuweatherTextSearch> textSearchMap;
	Map<String,AccuweatherForecastSearch> forecastMap;
	private static VIAJAISSRepositoryImplement instance=null;
	private int index=0;
	
	public static VIAJAISSRepositoryImplement getInstance() {
		if (instance == null) {
			instance = new VIAJAISSRepositoryImplement();
			instance.init();
		}
		return instance;
	}
	
	public void init() {
		driveMap= new HashMap<String,FileItem>();
		placesMap= new HashMap<String,Result>();
		textSearchMap = new HashMap<String,AccuweatherTextSearch>();
		forecastMap= new HashMap<String,AccuweatherForecastSearch>();
		
		//create Google Place
		Result sevilla= new Result();
		sevilla.setName("Seville");
		Result madrid= new Result();
		madrid.setName("Madrid");
		Result barcelona= new Result();
		barcelona.setName("Barcelona");
		Result londres= new Result();
		londres.setName("London");
		List<Result> ciudades= new ArrayList<Result>();
		ciudades.add(sevilla);
		ciudades.add(madrid);
		ciudades.add(barcelona);
		ciudades.add(londres);
		
		//create AccuweatherTextSearch
		AccuweatherTextSearch sevillaKey= new AccuweatherTextSearch();
		sevillaKey.setKey("306733");
		AccuweatherTextSearch madridKey= new AccuweatherTextSearch();
		madridKey.setKey("308526");
		AccuweatherTextSearch barcelonaKey= new AccuweatherTextSearch();
		barcelonaKey.setKey("307297");
		AccuweatherTextSearch londresKey= new AccuweatherTextSearch();
		londresKey.setKey("328328");
		List<AccuweatherTextSearch> keys= new ArrayList<AccuweatherTextSearch>();
		keys.add(sevillaKey);
		keys.add(madridKey);
		keys.add(barcelonaKey);
		keys.add(londresKey);
		
		//create AccuweatherForecast
		DailyForecast prediccion1= new DailyForecast();
		prediccion1.getTemperature();
		DailyForecast prediccion2= new DailyForecast();
		prediccion2.getTemperature();
		DailyForecast prediccion3= new DailyForecast();
		prediccion3.getTemperature();
		DailyForecast prediccion4= new DailyForecast();
		prediccion4.getTemperature();
		List<DailyForecast> dailyForecasts= new ArrayList<DailyForecast>();
		dailyForecasts.add(prediccion1);
		dailyForecasts.add(prediccion2);
		dailyForecasts.add(prediccion3);
		dailyForecasts.add(prediccion4);
		AccuweatherForecastSearch predicciones= new AccuweatherForecastSearch();
		predicciones.setDailyForecasts(dailyForecasts);
		
		//create Google Drive
		FileItem file= new FileItem();
		file.setTitle("Hola");
		FileItem file2= new FileItem();
		file2.setTitle("Viaje a Sevilla");
		addFile(file);
		addFile(file2);	
	}

	public Collection<Result> getAlojamientosCiudad() {
	return placesMap.values();
	}

	public Result getAlojamientoCiudad(String ciudad) {
	return placesMap.get(ciudad);
	}

	public void updateAlojamientosCiudad(Result ciudad) {
	Result c= placesMap.get(ciudad.getId());
	c.setName(ciudad.getName());
	}

	public void deleteAlojamientosCiudad(String name) {
	placesMap.remove(name);
	}

	public AccuweatherTextSearch getKey(String ciudad) {
		return textSearchMap.get(ciudad);
	}

	public AccuweatherForecastSearch getPrediccion(String key) {
		return forecastMap.get(key);
	}

	public Collection<FileItem> getAllFiles() {
		return driveMap.values();
	}

	public FileItem getFile(String id) {
		return driveMap.get(id);
	}

	public void addFile(FileItem file) {
		String id= "file"+ index++;
		file.setId(id);
		driveMap.put(id, file);
	}

	public void updateFile(FileItem file) {
		FileItem f= driveMap.get(file.getId());
		f.setTitle(file.getTitle());
		f.setFileSize(file.getFileSize());
		f.setModifiedDate(file.getModifiedDate());
	}

	public void deleteFile(String id) {
		driveMap.remove(id);
	}
}
