package aiss.model.repository;

import java.util.Collection;

import aiss.model.accuweatherForecast.*;
import aiss.model.accuweatherTextSearch.*;
import aiss.model.googleMaps.*;
import aiss.model.google.drive.*;

public interface VIAJAISSRepository {

	//Google Places
	public Collection<Result> getAlojamientosCiudad();
	public Result getAlojamientoCiudad(String ciudad);
	public void updateAlojamientosCiudad(Result ciudad);
	public void deleteAlojamientosCiudad(String name);
	
	//Accuweather TextSearch
	public AccuweatherTextSearch getKey(String ciudad);
	
	//Accuweather Forecast
	public AccuweatherForecastSearch getPrediccion(String key);
	
	//Google Drive
	public Collection<FileItem> getAllFiles();
	public FileItem getFile(String id);
	public void addFile(FileItem file);
	public void updateFile(FileItem file);
	public void deleteFile(String id);
}
