package aiss.model.resources;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.io.UnsupportedEncodingException;

import org.junit.Test;

import aiss.model.accuweatherTextSearch.AccuweatherTextSearch;

public class AccuweatherTextSearchTest {
		@Test
		public void getKeyTest() throws UnsupportedEncodingException{
			String query="London";
			AccuweatherTextSearchResources accuweatherTextSearch=
					new AccuweatherTextSearchResources();
			AccuweatherTextSearch[] accuweatherKey = accuweatherTextSearch.getKey(query);
			
			assertNotNull("La búsqueda devolvió null", accuweatherKey);
			assertFalse("El array está vacio", accuweatherKey.length==0);
			
			System.out.println(accuweatherKey[0].getKey());
			}
		}
