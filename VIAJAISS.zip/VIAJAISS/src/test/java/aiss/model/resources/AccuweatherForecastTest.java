package aiss.model.resources;

import static org.junit.Assert.assertNotNull;

import java.io.UnsupportedEncodingException;

import org.junit.Test;

import aiss.model.accuweatherForecast.AccuweatherForecastSearch;

public class AccuweatherForecastTest {
	@Test
	public void getForecastTest() throws UnsupportedEncodingException{
		String query= "Seville";
		AccuweatherForecastResources accuweatherForecastSearch=
				new AccuweatherForecastResources();
		AccuweatherForecastSearch accuweatherForecast = accuweatherForecastSearch.getForecast(query);
		
		assertNotNull("La búsqueda devolvió null", accuweatherForecast);
		
		for(int i=0;i<accuweatherForecast.getDailyForecasts().size();i++) {
			System.out.println("Previsión del tiempo para la mañana del día "+ (i+1) +" es: "+
					accuweatherForecast.getDailyForecasts().get(i).getDay().getIconPhrase());
			System.out.println("Previsión del tiempo para la noche del día "+ (i+1) +" es: "
					+accuweatherForecast.getDailyForecasts().get(i).getNight().getIconPhrase());
			System.out.println("La temperatura mínima para el día "+ (i+1) + " es: "+
					accuweatherForecast.getDailyForecasts().get(i).getTemperature().getMinimum()
					.getValue());
			System.out.println("La temperatura máxima para el día "+ (i+1) + " es: "+
					accuweatherForecast.getDailyForecasts().get(i).getTemperature().getMaximum()
					.getValue());
		}
	}

}
