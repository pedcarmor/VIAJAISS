package aiss.model.resources;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.io.UnsupportedEncodingException;

import org.junit.Test;

import aiss.model.googleMaps.GoogleMapsSearch;

public class GoogleMapsTest {
		@Test
		public void getResultsTest() throws UnsupportedEncodingException{
			String query="Sevilla";
			GoogleMapsResources googleMaps= new GoogleMapsResources();
			GoogleMapsSearch googleMapsResults = googleMaps.getResults(query);
			
			assertNotNull("La búsqueda devolvió null",googleMapsResults);
			assertNotNull("La búsqueda devolvió null",googleMapsResults.getResults());
			assertFalse("El número de alojamientos en "+query+" es cero",
					googleMapsResults.getResults().size()==0);
			
			
			System.out.println("Hemos encontrado "+googleMapsResults.getResults().size()+
					" alojamientos en "+ query+ ":");
			for(int i=0;i<googleMapsResults.getResults().size();i++) {
				System.out.println("La búsqueda en "+query+" devolvió "+ 
			googleMapsResults.getResults().get(i).getName());
				for(int j=0; j<googleMapsResults.getResults().get(i).getPhotos().size(); j++) {
					System.out.println("Fotos del alojamiento: "
							+googleMapsResults.getResults().get(i).getPhotos().get(j));
				}
			}
			
			
		}
}
